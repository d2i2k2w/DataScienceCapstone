#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)
shinyUI(pageWithSidebar(
  headerPanel("Data Science Capstone: Trigram Prediction Model"),
  sidebarPanel(
    textInput(inputId = "word1", label = "Input Word1"),
    textInput(inputId = "word2", label = "Input Word2"),
    actionButton("goButton", "Go!")
  ),
  mainPanel(
    p('Trigram: Word1, Word2, Word3'),
    textOutput('trigram')
  ) 
))
