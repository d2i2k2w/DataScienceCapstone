#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)
shinyUI(pageWithSidebar(
  headerPanel("Data Science Capstone"),
  sidebarPanel(
    textInput(inputId = "word1", label = "Input Word1"),
    textInput(inputId = "word2", label = "Input Word2"),
    actionButton("goButton", "Go!")
  ),
  mainPanel(
    p('Output Word1'),
    textOutput('word1'),
    p('Output Word2'),
    textOutput('word2'),
    p('Output Word3 : Word1, Word2'),
    textOutput('word3')
  ) 
))
