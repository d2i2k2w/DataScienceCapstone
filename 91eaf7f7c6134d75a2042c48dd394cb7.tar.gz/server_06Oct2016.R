#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)
shinyServer(
  function(input, output) {
    output$word1 <- renderText({input$word1})
    output$word2 <- renderText({input$word2})
    output$word3 <- renderText({
      input$goButton
      isolate(paste(input$word1, input$word2))
   })
  }
)
